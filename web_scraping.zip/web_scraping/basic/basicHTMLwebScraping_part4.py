from bs4 import BeautifulSoup

with open('index.html','r') as html_file:
    content = html_file.read()
    
    soup = BeautifulSoup(content, 'lxml')
    # extracting h5 tag
    courses_html_tags= soup.find_all('h5')
    #showing text of tags
    for courses in courses_html_tags:
        print(courses.text)