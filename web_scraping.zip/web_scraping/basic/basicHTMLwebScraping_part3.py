from bs4 import BeautifulSoup

with open('index.html','r') as html_file:
    content = html_file.read()
    
    soup = BeautifulSoup(content, 'lxml')
    # extracting h5 tag

    tags = soup.find_all('h5') #if we use .find() then it will grab just frist h5
    print(tags)