from bs4 import BeautifulSoup

import requests

def advance_scraping_exmaple():
    html_text=requests.get('https://books.toscrape.com/').text
    #print(html_text)
    soup = BeautifulSoup(html_text,'lxml')
    var1 = soup.find('div', class_='col-sm-8 col-md-9')
    var2 = var1.find('div',class_='page-header action').text.replace(' ','*')

    #print(var2.h1.text)

    # books
    var1 = soup.find('ol', class_='row')
    var2 = var1.find_all('li', class_='col-xs-6 col-sm-4 col-md-3 col-lg-3')

    # Iterate over each element in var2 and find articles inside each 'li' item
    var3 = []
    for item in var2:
        articles = item.find_all('article', class_='product_pod')
        var3.extend(articles)  # Collect all found articles

    # Now, find the 'h3' and clean the text
    var4 = []
    for article in var3:
        h3 = article.find('h3')
        if h3:  # Ensure there is an 'h3' tag
            var4.append(h3.text.replace('...', ''))

    # Print the cleaned text
    print(var4)


if __name__ == '__main__':
    advance_scraping_exmaple()