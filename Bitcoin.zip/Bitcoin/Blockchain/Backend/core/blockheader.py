import sys
import os
sys.path.append(os.path.abspath("C:/Users/hanif/Desktop/Bitcoin"))

from Blockchain.Backend.util.util import hash256  # Make sure this matches your renamed util file

class BlockHeader:  # ✅ Correct class name
    def __init__(self, version, prevBlockHash, merkleRoot, timestamp, bits):
        self.version = version
        self.prevBlockHash = prevBlockHash
        self.merkleRoot = merkleRoot
        self.timestamp = timestamp
        self.bits = bits
        self.nonce = 0
        self.blockHash = ''

    def mine(self):
        while self.blockHash[0:2] != '00':
            self.blockHash = hash256((
                str(self.version) +
                self.prevBlockHash +
                self.merkleRoot +
                str(self.timestamp) +
                self.bits +
                str(self.nonce)
            ).encode()).hex()
            self.nonce += 1
            print(f"Mining... Nonce: {self.nonce}", end='\r')
